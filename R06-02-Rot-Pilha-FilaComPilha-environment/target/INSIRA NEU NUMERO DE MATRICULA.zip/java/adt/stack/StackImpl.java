package adt.stack;

public class StackImpl<T> implements Stack<T> {

	private T[] array;
	private int top;

	@SuppressWarnings("unchecked")
	public StackImpl(int size) {
		array = (T[]) new Object[size];
		top = -1;
	}

	@Override
	public T top() {

		if (this.isEmpty()) {
			try {
				throw new StackUnderflowException();
			} catch (StackUnderflowException e) {
				System.out.println(e);
			}
		}
		return array[top];
	}

	@Override
	public boolean isEmpty() {
		return this.top == -1;
	}

	@Override
	public boolean isFull() {
		return this.top == this.array.length - 1;
	}

	@Override
	public void push(T element) throws StackOverflowException {
		if (this.isFull()) {
			throw new StackOverflowException();
		}
		this.top += 1;
		this.array[this.top] = element;
		System.out.println(this.array[this.top]);
		
	}

	@Override
	public T pop() throws StackUnderflowException {
		if (this.isEmpty()) {
			throw new StackUnderflowException();
		}
		T value_top = this.array[this.top];
		this.top -= 1;
		return value_top;
	}
	
	public static void main(String[] args) throws StackUnderflowException, StackOverflowException {
		StackImpl<Integer> array = new StackImpl<Integer>(3);
		array.push(1);
		array.push(2);
		array.push(3);
		
		
	}
	
	
}
